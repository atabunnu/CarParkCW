
interface CarParkManager {
    
   public void AddNewVehicle();
   public void RemoveVehicle();
   public void DispalyList();
   public void VehiclePercentage();
   public void MostParkedTime();
    
}
