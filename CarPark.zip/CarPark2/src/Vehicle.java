
public abstract class Vehicle {
   
    DateTime dateNtime;
    
     String VehiclePlateID;
     String VehicleBrand;
     private  DateTime VehicleInTime;
     
  
     
    Vehicle (DateTime InTime){
    this.VehicleInTime  = InTime;
    
    }



	public DateTime getDateNtime() {
		return dateNtime;
	}



	public void setDateNtime(DateTime dateNtime) {
		this.dateNtime = dateNtime;
	}



	public String getVehiclePlateID() {
		return VehiclePlateID;
	}



	public void setVehiclePlateID(String vehiclePlateID) {
		VehiclePlateID = vehiclePlateID;
	}



	public String getVehicleBrand() {
		return VehicleBrand;
	}



	public void setVehicleBrand(String vehicleBrand) {
		VehicleBrand = vehicleBrand;
	}



	public DateTime getVehicleInTime() {
		return VehicleInTime;
	}



	public void setVehicleInTime(DateTime vehicleInTime) {
		VehicleInTime = vehicleInTime;
	}

    
   

}
