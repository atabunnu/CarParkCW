
public class CarParkSystem {

    public static void main(String[] args) {
        
        
        System.out.println("===========================================");
        System.out.println("      Westminster Car Park Manager  	   ");
        System.out.println("===========================================");
        System.out.println();
      
        WestminsterCarParkManager CPM = new WestminsterCarParkManager();
       CPM.menu();
       
        
        
    }
    
}
