

import static com.sun.org.apache.xml.internal.security.keys.keyresolver.KeyResolver.length;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import static java.lang.String.format;
import static java.lang.String.format;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;


public class WestminsterCarParkManager implements CarParkManager {
    Scanner sc = new Scanner(System.in);
    static ArrayList<Vehicle> VehicleArray = new ArrayList<Vehicle>(20);
    Vehicle[] array;
    static int VehicleNumber = 0;
    static int freeSpaces;
    
    static long hour;
    static long longtime=0;
    static String longid;
    static String longtype;
    
    static String PlateID;
    static String VehicleType;
    
    static String startDate;
    static String endDate;
    static String leaveTime;
    static String finalDate;
    
//    static String Id;
    public void menu(){
        
        System.out.println("Enter your letter of choice");
        System.out.println("N - Adding a new vehicle");
        System.out.println("R - Remove a vehicle");
        System.out.println("L - List of parked vehicles");
        System.out.println("P - Percentage of parked vehicle types");
        System.out.println("T - Vehicle whick has the longest park time");
        String se = sc.next();
        
        switch(se.toUpperCase())
        {
        case "N" : AddNewVehicle();
        break;
        case "R" : RemoveVehicle();
        break;
        case "L" : DispalyList();
        break;
        case "P" : VehiclePercentage();
        break;
        case "T" : MostParkedTime();
        break;
        
        default :
        System.out.println("Incorrect Input");
        menu();
        }
        
    }
    
    
    
    
    @Override
    public void AddNewVehicle() {
        
    	freeSpaces = 19-VehicleNumber;
        System.out.println("");  
        System.out.println("Enter a valid vehicle plate ID:");
        String vehicleId = sc.next();
         System.out.println("Enter a valid vehicle brand:");
        String vehicleBrand = sc.next();
         System.out.println("Enter a valid entry date: [DD/MM/YYYY]");
        String vehicleDate = sc.next();
         System.out.println("Enter a valid entry time: [HH/MM]");
        String vehicleTime = sc.next();
        
               System.out.println("----------------------------------------------");
               System.out.println("          ADD VEHICLE TO CAR PARK             ");
               System.out.println("----------------------------------------------");
               System.out.println("1 - To add a Car");
               System.out.println("2 - To add a Van");
               System.out.println("3 - To add a Motorbike");
               
               int choise1 = sc.nextInt();
               
               switch(choise1){
                   case 1:
                     if(VehicleNumber<19){
                       
                       System.out.println("Available Free Slots: "+freeSpaces);
                       
                             
                       System.out.println("--- Add A Car ---");
                      
                       DateTime dateTime = new DateTime();
                        Car car = new Car(dateTime);
                       System.out.println("");
                       System.out.println("Enter the car color:");
                       String carColor = sc.next();
                       System.out.println("Enter the number Of doors in the car:");
                       String carNoOfDoors = sc.next();
                       car.setVehiclePlateID(vehicleId);
                       car.setVehicleBrand(vehicleBrand);
                       car.setDoorNum(carNoOfDoors);
                       car.setColor(carColor);
                       dateTime.setDate(vehicleDate);
                       dateTime.setTime(vehicleTime);
                      
                       
                       
                       VehicleArray.add(car);
                 
                       VehicleNumber++;
                       
                       car.getDateNtime();
                      // System.out.println(vehicle.toString());
                      
                       
                       
                        menu();
                       
                     }else{
                         System.out.println("*** Car Park Full ***");
                         
                         menu();
                     }
                     break;
                   case 2:
                       
                       if(VehicleNumber<18){
                        System.out.println("Free Slots: "+freeSpaces);
                       
                       System.out.println("--- Add a Van ---");
                      
                       DateTime dateTime2 = new DateTime();
                        Van van = new Van(dateTime2);
                       System.out.println("Enter the cargo volume of the Van: ");
                       String vanCargoVol = sc.next();
                       van.setVehiclePlateID(vehicleId);
                       van.setVehicleBrand(vehicleBrand);
                       van.setCargoCapacity(vanCargoVol);
                       dateTime2.setDate(vehicleDate);
                       dateTime2.setTime(vehicleTime);
                       
                       VehicleArray.add(van);
                       VehicleArray.add(van);
                       
                       VehicleNumber++;
                       VehicleNumber++;
                       
                       
                       menu();
                       
                       }else{
                           System.out.println("*** Car Park Full ***");
                           
                           menu();
                       }
                      break; 
                   case 3:
                       
                     if(VehicleNumber<19){
                       
                       System.out.println("Free Slots: "+freeSpaces);
                         System.out.println("");
                       
                        System.out.println("--- Add A Motorbike ---");
                       
                       DateTime dateTime3 = new DateTime();
                       Motorbike motorbike = new Motorbike(dateTime3);
                       System.out.println("Enter the engine capacitys: ");
                       String SizeOfEngine = sc.next();
                       motorbike.setVehiclePlateID(vehicleId);
                       motorbike.setVehicleBrand(vehicleBrand);
                       motorbike.setEngineSize(SizeOfEngine);
                       dateTime3.setDate(vehicleDate);
                       dateTime3.setTime(vehicleTime);
                       
                       VehicleArray.add(motorbike);
                       VehicleNumber++;
                       menu();
               }else{
                      System.out.println("*** Car Park Full ***");
                      
                      menu();
                     }
       
                    break;
       
               }
        
        
    }
    
    
    @Override
    public void RemoveVehicle() {
        
      
		// TODO Auto-generated method stub
		//DispalyVehicleList();
		System.out.println("Enter the vehicle ID of the removing vehicle ");
		Scanner sc = new Scanner(System.in);
		String choice = sc.next();
		int arrayIndex = 0;
		boolean found = false;
		for (Vehicle h : VehicleArray) {
			if (h.getVehiclePlateID().equalsIgnoreCase(choice)) {
                            startDate =(h.getDateNtime()).toString();
                            
                            System.out.println("Leave Date [YYYY/MM/DD]");
                            //DateTime dateTimeT = new DateTime();
                            endDate = sc.next();
                            
                            System.out.println("Leave Time [HH:MM]");
                            leaveTime =sc.next();
                            
                            finalDate=(endDate+" "+leaveTime);
                            
                            PlateID = h.getVehiclePlateID();
                      
				found = true;
				if (h instanceof Van) {
					System.out.println("A van left"); 
					VehicleType="Van";
				} else if (h instanceof Car) {
					System.out.println("A car left");
					VehicleType = "Car";
				} else if (h instanceof Motorbike) {
					System.out.println("A bike left");
					VehicleType = "Motorbike";
				}
				break;
			}
			arrayIndex++;
		}
		if (found) {
			VehicleArray.remove(arrayIndex);
		}else{
			System.err.println("Invalid vehicle ID");
		}
	
        payment();
    }

    public void payment(){
                            
                String dateStart = startDate;
		String dateStop = finalDate;

		//HH converts hour in 24 hours format (0-23), day calculation
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm");

		Date d1 = null;
		Date d2 = null;

		try {
			d1 = format.parse(dateStart);
			d2 = format.parse(dateStop);

			//in milliseconds
			long diff = d2.getTime() - d1.getTime();

			
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;
			long diffDays = diff / (24 * 60 * 60 * 1000);
                        
                        
                        long hour24 = diffDays*24;
                        
                        hour=hour24+diffHours;
                        
                       
                        
                        
                        
                        
                        
                        if(hour>=0){
                        
                        if(hour>3){
                            long nexthour=hour-3;
                            long price = nexthour+9;
                            System.out.println("$"+price+" parking charge");
                        }else{
                              long price2 = hour*3;
                              System.out.println("$"+price2+" parking charge");
                            }
                        }else{
                            System.out.println("Invalid time enterd");
                        }
                        
			

		} catch (Exception e) {
			e.printStackTrace();
		}       
        
      
                menu();
    }
    
    
    
    
    
    
    
    @Override
    public void DispalyList(){
        
        
       

		array = new Vehicle[0];
		array = new Vehicle[VehicleArray.size()];
		int counter = 0;
		for (Vehicle h : VehicleArray) {
			array[counter] = h;
			counter++;
		}

		boolean swapped = true;

		int j = 0;
		Vehicle tmp;

		while (swapped) {
			swapped = false;
			j++;
			for (int i = 0; i < array.length - 1; i++) {
                            
                          String l = (array[i].getDateNtime()).toString();
                            
                            String[] dateSeperater = (l.split("\\ "));
                            
                          String date = dateSeperater[0];
			  String time= dateSeperater[1];
                            
                          DateTime dateTime = new DateTime();
                          
                          dateTime.setDate(date);
                          dateTime.setTime(time);
                          
                          int year1 = dateTime.getYear();
                          
                            
                          
                          String f = (array[i+1].getDateNtime()).toString();
                            
                            String[] dateSeperater1 = (f.split("\\ "));
                            
                          String date1 = dateSeperater1[0];
			  String time1= dateSeperater1[1];
                            
                          DateTime dateTime1 = new DateTime();
                          
                          dateTime.setDate(date1);
                          dateTime.setTime(time1);
                          
                          int year2 = dateTime.getYear();
                          
                       
                          
				if (year1 > year2) {
					tmp = array[i];
					array[i] = array[i + 1];
					array[i + 1] = tmp;
					swapped = true;
				}
			}
		}

		swapped = true;
		while (swapped) {
			swapped = false;
			j++;
			for (int i = 0; i < array.length - 1; i++) {
                            
                             String l = (array[i].getDateNtime()).toString();
                            
                            String[] dateSeperater = (l.split("\\ "));
                            
                          String date = dateSeperater[0];
			  String time= dateSeperater[1];
                            
                          DateTime dateTime = new DateTime();
                          
                          dateTime.setDate(date);
                          dateTime.setTime(time);
                          
                          int year1 = dateTime.getYear();
                          int month1 = dateTime.getMonth();
                          
                          String f = (array[i+1].getDateNtime()).toString();
                            
                            String[] dateSeperater1 = (f.split("\\ "));
                            
                          String date1 = dateSeperater1[0];
			  String time1= dateSeperater1[1];
                            
                          DateTime dateTime1 = new DateTime();
                          
                          
                          dateTime.setDate(date1);
                          dateTime.setTime(time1);
                          
                          int year2 = dateTime.getYear();
                          int month2 = dateTime.getMonth();
                            
				if (year1 == year2) {
					if (month1 > month2) {
						tmp = array[i];
						array[i] = array[i + 1];
						array[i + 1] = tmp;
						swapped = true;
					}
				}
			}
		}

		swapped = true;
		while (swapped) {
			swapped = false;
			j++;
			for (int i = 0; i < array.length - 1; i++) {
                            
                            String l = (array[i].getDateNtime()).toString();
                            
                            String[] dateSeperater = (l.split("\\ "));
                            
                          String date = dateSeperater[0];
			  String time= dateSeperater[1];
                            
                          DateTime dateTime = new DateTime();
                          
                          dateTime.setDate(date);
                          dateTime.setTime(time);
                          
                          int year1 = dateTime.getYear();
                          int month1 = dateTime.getMonth();
                          int day1 = dateTime.getdate();
                          
                          String f = (array[i+1].getDateNtime()).toString();
                            
                            String[] dateSeperater1 = (f.split("\\ "));
                            
                          String date1 = dateSeperater1[0];
			  String time1= dateSeperater1[1];
                            
                          DateTime dateTime1 = new DateTime();
                          
                          
                          dateTime.setDate(date1);
                          dateTime.setTime(time1);
                          
                          int year2 = dateTime.getYear();
                          int month2 = dateTime.getMonth();
                          int day2 = dateTime.getdate();
                          
				if (year1 == year2) {
					if (month1 == month2) {
						if (day1 > day2) {
							tmp = array[i];
							array[i] = array[i + 1];
							array[i + 1] = tmp;
							swapped = true;

						}
					}
				}
			}
		}

		swapped = true;
		while (swapped) {
			swapped = false;
			j++;
			for (int i = 0; i < array.length - 1; i++) {
                            
                            
                            String l = (array[i].getDateNtime()).toString();
                            
                            String[] dateSeperater = (l.split("\\ "));
                            
                          String date = dateSeperater[0];
			  String time= dateSeperater[1];
                            
                          DateTime dateTime = new DateTime();
                          
                          dateTime.setDate(date);
                          dateTime.setTime(time);
                          
                          int year1 = dateTime.getYear();
                          int month1 = dateTime.getMonth();
                          int day1 = dateTime.getdate();
                          int hour1 = dateTime.getHour();
                          
                          String f = (array[i+1].getDateNtime()).toString();
                            
                            String[] dateSeperater1 = (f.split("\\ "));
                            
                          String date1 = dateSeperater1[0];
			  String time1= dateSeperater1[1];
                            
                          DateTime dateTime1 = new DateTime();
                          
                          
                          dateTime.setDate(date1);
                          dateTime.setTime(time1);
                          
                          int year2 = dateTime.getYear();
                          int month2 = dateTime.getMonth();
                          int day2 = dateTime.getdate();
                          int hour2 = dateTime.getHour();
                            
                            
				if (year1 == year2) {
					if (month1 == month2) {
						if (day1 == day2) {
							if (hour1 > hour2) {
								tmp = array[i];
								array[i] = array[i + 1];
								array[i + 1] = tmp;
								swapped = true;
							}
						}
					}
				}

			}
		}

		swapped = true;
		while (swapped) {
			swapped = false;
			j++;
			for (int i = 0; i < array.length - 1; i++) {
                            
                            
                            
				String l = (array[i].getDateNtime()).toString();
                            
                            String[] dateSeperater = (l.split("\\ "));
                            
                          String date = dateSeperater[0];
			  String time= dateSeperater[1];
                            
                          DateTime dateTime = new DateTime();
                          
                          dateTime.setDate(date);
                          dateTime.setTime(time);
                          
                          int year1 = dateTime.getYear();
                          int month1 = dateTime.getMonth();
                          int day1 = dateTime.getdate();
                          int hour1 = dateTime.getHour();
                          int minute1 = dateTime.getMinute();
                          
                          String f = (array[i+1].getDateNtime()).toString();
                            
                            String[] dateSeperater1 = (f.split("\\ "));
                            
                          String date1 = dateSeperater1[0];
			  String time1= dateSeperater1[1];
                            
                          DateTime dateTime1 = new DateTime();
                          
                          
                          dateTime.setDate(date1);
                          dateTime.setTime(time1);
                          
                          int year2 = dateTime.getYear();
                          int month2 = dateTime.getMonth();
                          int day2 = dateTime.getdate();
                          int hour2 = dateTime.getHour();
                          int minute2 = dateTime.getMinute();
                            
				if (year1 == year2) {
					if (month1 == month2) {
						if (day1 == day2) {
							if (hour1 > hour2) {
								if (minute1  > minute2 ) {
									tmp = array[i];
									array[i] = array[i + 1];
									array[i + 1] = tmp;
									swapped = true;
								}
							}
						}
					}
				}

			}
		}

	
        


          
        for(int i = 0; i < VehicleArray.size(); i++){
            System.out.println(array[i].getVehiclePlateID());
            System.out.println(array[i].getDateNtime());
            
                                      if (array[i] instanceof Van) {
					System.out.println("A van is leaving.");      
				} else if (array[i] instanceof Car) {
					System.out.println("A car is leaving.");
				} else if (array[i] instanceof Motorbike) {
					System.out.println("A bike is leaving.");
				}
            System.out.println("  ");
        }


        menu();

    }

    @Override
    public void VehiclePercentage() {
        
        int carCount=0;
        int vanCount=0;
        int motorbikeCount=0;
        
        
       for (Vehicle h : VehicleArray) {
           if( h !=null){
                               if (h instanceof Van) {
					vanCount++;
				} else if (h instanceof Car) {
					carCount++;
				} else if (h instanceof Motorbike) {
					motorbikeCount++;
				}
           }
       }
       
       int total = carCount+vanCount+motorbikeCount;
       
        System.out.println("  ");
        System.out.println("Cars Preantage"+carCount/total*100+"%");
        System.out.println("Vans Preantage"+vanCount/total*100+"%");
        System.out.println("Motorbikes Preantage"+motorbikeCount/total*100+"%");
        System.out.println("  ");
        menu();
    }

    public void longstvehicle(){
        if(longtime<hour){
             longtime=hour;
    
        longid=PlateID;
        longtype=VehicleType;
        
        }
    
    }
    
    @Override
    public void MostParkedTime() {
         
             System.out.println(longid);
             System.out.println(longtype);
             System.out.println(longtime);
       
    }

    
    
    
}
