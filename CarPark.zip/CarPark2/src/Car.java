
public class Car extends Vehicle {
    
    
   private  String Vehicle = "Car";
   private  String DoorNum;
   private  String Color;
  

    public Car(DateTime InTime) {
        super(InTime);
    }

   

    public String getDoorNum() {
		return DoorNum;
	}



	public void setDoorNum(String doorNum) {
		DoorNum = doorNum;
	}



	public String getColor() {
		return Color;
	}



	public void setColor(String color) {
		Color = color;
	}



	public String toString() {
        return "ID : " + getVehiclePlateID() + "\n" + " Brand : " + getVehicleBrand() + "\n" + " Number Of Doors : " + getDoorNum();
    }
}
