
public class Van extends Vehicle {
    
    private  static String Vehicle = "Van";
    private  String CargoCapacity;

    public Van(DateTime InTime) {
        super(InTime);
    }
   
    

    public String getCargoCapacity() {
		return CargoCapacity;
	}



	public void setCargoCapacity(String cargoCapacity) {
		CargoCapacity = cargoCapacity;
	}



	public String toString() {
        return "ID : " + getVehiclePlateID() + "\n" + " Brand : " + getVehicleBrand() + "\n" + " Cargo Volume : " + getCargoCapacity();
    }
    
  
   
}
