import java.util.Scanner;

public class DateTime {
    
    static Scanner sc = new Scanner(System.in);
		
		String CheckMinute ="([0-5]\\d|60)";
		String CheckHour = "([0|1]\\d|2[0-4])";
		String CheckDate = "((1|2)\\d|3(0|1)|0[1-9]|[1-9])";
		String CheckMonth = "(0[1-9]|1[0-2])";
		String CheckYear = "[2-9]\\d{3}";
		
		
		private int minute;
		private int hour;
		private int date;
		private int month;
		private int year;
		
		
		
		public void setDate(String inputDate){
			if(inputDate.matches(CheckDate + "\\/"+CheckMonth +"\\/" + CheckYear)){
				String[] DDMMYY = (inputDate.split("\\/"));
				 year = Integer.parseInt(DDMMYY[0]);
				 month = Integer.parseInt(DDMMYY[1]);
				 date = Integer.parseInt(DDMMYY[2]);
			}else{
				System.out.println("Enter a valid date on the format of \"DD/MM/YY\"");
				setDate(sc.next());
                                
			}
		}
		
	
		
		public void setTime(String inputTime){
			if(inputTime.matches(CheckHour + "\\:"+CheckMinute )){
				String[] HHMM = (inputTime.split("\\:"));
				 hour = Integer.parseInt(HHMM[0]);
				 minute = Integer.parseInt(HHMM[1]);
				
			
			}else{
				System.out.println("Please enter a valid time on \"HH:mm\" format: ");
				setTime(sc.next());
			}
		}
		
		public int getYear(){
			return year ;
		}
		public int getMonth(){
			return month ;
		}
		public int getdate(){
			return date ;
		}
		public int getHour(){
			return hour ;
		}
		public int getMinute(){
			return minute ;
		}
		
                
		
	
		public String toString(){
			return String.format("%d/%d/%d %d:%d", year,month,date,hour,minute);
		}
		

		
		
    
    
}
