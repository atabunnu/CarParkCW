
public class CarParkSystem {

	//main menu
    public static void main(String[] args) {
        
        
        System.out.println("===========================================");
        System.out.println("      Westminster Car Park Manager  	   ");
        System.out.println("===========================================");
        System.out.println();
        
        
        //creating new object of WestminsterCarParkManager
        WestminsterCarParkManager CPM = new WestminsterCarParkManager();
        
        //invoking main menu
        CPM.menu();
       
        
        
    }
    
}
