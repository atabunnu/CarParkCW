import java.util.Scanner;

public class DateTime {
    
    static Scanner sc = new Scanner(System.in);
		
    	//creating variables to check date and time 
		String CheckMinute ="([0-5]\\d|60)";
		String CheckHour = "([0|1]\\d|2[0-4])";
		String CheckDate = "((1|2)\\d|3(0|1)|0[1-9]|[1-9])";
		String CheckMonth = "(0[1-9]|1[0-2])";
		String CheckYear = "[2-9]\\d{3}";
		
		//variables for DateTime attributes
		private int minute;
		private int hour;
		private int date;
		private int month;
		private int year;
		
		
		
		public void setDate(String inputDate){
			
			//checking if the input date is correct
			if(inputDate.matches(CheckDate + "\\/"+CheckMonth +"\\/" + CheckYear)){
				String[] DDMMYY = (inputDate.split("\\/"));
				 year = Integer.parseInt(DDMMYY[0]);
				 month = Integer.parseInt(DDMMYY[1]);
				 date = Integer.parseInt(DDMMYY[2]);
			}else{
				
				//if the date is incorrect prompt the user
				System.out.println("Enter a valid date on the format of \"DD/MM/YY\"");
				setDate(sc.next());
                                
			}
		}
		
	
		
		public void setTime(String inputTime){
			
			//checking if the input time is correct
			if(inputTime.matches(CheckHour + "\\:"+CheckMinute )){
				String[] HHMM = (inputTime.split("\\:"));
				 hour = Integer.parseInt(HHMM[0]);
				 minute = Integer.parseInt(HHMM[1]);
				
			
			}else{
				
				//if the time is incorrect prompt the user
				System.out.println("Please enter a valid time on \"HH:mm\" format: ");
				setTime(sc.next());
			}
		}
		
		
		//getters and setters for DateTime attributes
		public int getYear(){
			return year ;
		}
		public int getMonth(){
			return month ;
		}
		public int getdate(){
			return date ;
		}
		public int getHour(){
			return hour ;
		}
		public int getMinute(){
			return minute ;
		}
		
                
		
		//generating constructor
		public String toString(){
			return String.format("%d/%d/%d %d:%d", year,month,date,hour,minute);
		}
		

		
		
    
    
}
