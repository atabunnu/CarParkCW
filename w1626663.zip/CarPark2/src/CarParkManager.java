
interface CarParkManager {
    
	//system interface
	
	//required main functionalities for the car park system
	public void AddNewVehicle();
	public void RemoveVehicle();
	public void DispalyList();
	public void VehiclePercentage();
	public void MostParkedTime();
    
}
