
public class Car extends Vehicle {
    
   //setting car attributes 
   private  String Vehicle = "Car";
   private  String DoorNum;
   private  String Color;
  
   //car parking-in time
    public Car(DateTime InTime) {
        super(InTime);
    }

   
    //getter for number of doors
    public String getDoorNum() {
		return DoorNum;
	}


  //setter for number of doors
	public void setDoorNum(String doorNum) {
		DoorNum = doorNum;
	}


	//getter for car color
	public String getColor() {
		return Color;
	}


	//setter for car color
	public void setColor(String color) {
		Color = color;
	}


	//generating constructor
	public String toString() {
        return "ID : " + getVehiclePlateID() + "\n" + " Brand : " + getVehicleBrand() + "\n" + " Number Of Doors : " + getDoorNum();
    }
}
