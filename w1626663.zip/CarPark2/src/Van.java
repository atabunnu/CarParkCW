
public class Van extends Vehicle {
	
	//setting van attributes
    private  static String Vehicle = "Van";
    private  String CargoCapacity;
    
    //van parking-in time
    public Van(DateTime InTime) {
        super(InTime);
    }
   
    
    //getter for cargo capacity
    public String getCargoCapacity() {
		return CargoCapacity;
	}


    //setter for cargo capacity
	public void setCargoCapacity(String cargoCapacity) {
		CargoCapacity = cargoCapacity;
	}


	//generating constructor
	public String toString() {
        return "ID : " + getVehiclePlateID() + "\n" + " Brand : " + getVehicleBrand() + "\n" + " Cargo Volume : " + getCargoCapacity();
    }
    
  
   
}
