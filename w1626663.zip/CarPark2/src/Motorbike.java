
public class Motorbike extends Vehicle {
    
	//setting motorbike attributes
   private  String VehicleType = "Motorbike";
   private  String BikeCC;
  
   	//motorbike parking-in time
    public Motorbike(DateTime VehicleInTime) {
        super(VehicleInTime);
    }

    //getter for engine size
    public String getEngineSize() {
        return BikeCC;
    }

    //setter for engine size
    public void setEngineSize(String EngineSize) {
        this.BikeCC = EngineSize;
    }

    //generating constructor
    public String toString() {
        return "ID : " + getVehiclePlateID() + "\n" + " Brand : " + getVehicleBrand() + "\n" + " Engine Capacity : " + getEngineSize();
    } 
   

}
