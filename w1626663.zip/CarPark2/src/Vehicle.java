
public abstract class Vehicle {
   
	
	//setting attributes
    DateTime dateNtime;
    
     String VehiclePlateID;
     String VehicleBrand;
     private  DateTime VehicleInTime;
     
  
   //vehicle parking-in time
    Vehicle (DateTime InTime){
    this.VehicleInTime  = InTime;
    
    }


    //getter for date and time
	public DateTime getDateNtime() {
		return dateNtime;
	}


	//setter for date and time
	public void setDateNtime(DateTime dateNtime) {
		this.dateNtime = dateNtime;
	}


	//getter for plate ID
	public String getVehiclePlateID() {
		return VehiclePlateID;
	}


	//setter for plate ID
	public void setVehiclePlateID(String vehiclePlateID) {
		VehiclePlateID = vehiclePlateID;
	}


	//getter for vehicle brand
	public String getVehicleBrand() {
		return VehicleBrand;
	}


	//setter for vehicle brand
	public void setVehicleBrand(String vehicleBrand) {
		VehicleBrand = vehicleBrand;
	}


	//getter for vehicle in time
	public DateTime getVehicleInTime() {
		return VehicleInTime;
	}


	//setter for vehicle in time
	public void setVehicleInTime(DateTime vehicleInTime) {
		VehicleInTime = vehicleInTime;
	}

    
   

}
